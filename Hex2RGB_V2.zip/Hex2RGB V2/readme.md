The content of input.txt should contain the HEX code without any additional characters or whitespace. For example, if the HEX code is "#FF0000", input.txt should contain only "FF0000".

made by TOMskuh on GitHub (with a little assistent of AI cuz i am a beginner coder)